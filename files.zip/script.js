const canvas = document.getElementById('pongCanvas');
const ctx = canvas.getContext('2d');

// Constants
const PADDLE_WIDTH = 10;
const PADDLE_HEIGHT = 80;
const BALL_RADIUS = 10;
const PLAYER_X = 20;
const AI_X = canvas.width - 20 - PADDLE_WIDTH;
const PADDLE_SPEED = 6;
const AI_REACTION = 0.08; // Lower is slower AI

// State
let playerY = canvas.height / 2 - PADDLE_HEIGHT / 2;
let aiY = canvas.height / 2 - PADDLE_HEIGHT / 2;
let ballX = canvas.width / 2;
let ballY = canvas.height / 2;
let ballSpeedX = 5 * (Math.random() > 0.5 ? 1 : -1);
let ballSpeedY = 3 * (Math.random() > 0.5 ? 1 : -1);

// Mouse Control
canvas.addEventListener('mousemove', function (evt) {
    const rect = canvas.getBoundingClientRect();
    const root = document.documentElement;
    let mouseY = evt.clientY - rect.top - root.scrollTop;
    playerY = mouseY - PADDLE_HEIGHT / 2;
    if (playerY < 0) playerY = 0;
    if (playerY > canvas.height - PADDLE_HEIGHT)
        playerY = canvas.height - PADDLE_HEIGHT;
});

// Draw functions
function drawRect(x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

function drawCircle(x, y, r, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2, false);
    ctx.closePath();
    ctx.fill();
}

function drawNet() {
    ctx.strokeStyle = "#fff";
    ctx.setLineDash([6, 10]);
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 0);
    ctx.lineTo(canvas.width / 2, canvas.height);
    ctx.stroke();
    ctx.setLineDash([]);
}

// Collision detection
function paddleCollision(paddleX, paddleY) {
    return (
        ballX + BALL_RADIUS > paddleX &&
        ballX - BALL_RADIUS < paddleX + PADDLE_WIDTH &&
        ballY + BALL_RADIUS > paddleY &&
        ballY - BALL_RADIUS < paddleY + PADDLE_HEIGHT
    );
}

// Game loop
function gameLoop() {
    // Move ball
    ballX += ballSpeedX;
    ballY += ballSpeedY;

    // Wall collision
    if (ballY - BALL_RADIUS < 0 || ballY + BALL_RADIUS > canvas.height) {
        ballSpeedY = -ballSpeedY;
    }

    // Player paddle collision
    if (paddleCollision(PLAYER_X, playerY)) {
        ballSpeedX = -ballSpeedX;
        // Add a bit of "spin" based on where it hit the paddle
        let collidePoint = ballY - (playerY + PADDLE_HEIGHT / 2);
        ballSpeedY = collidePoint * 0.18;
    }

    // AI paddle collision
    if (paddleCollision(AI_X, aiY)) {
        ballSpeedX = -ballSpeedX;
        let collidePoint = ballY - (aiY + PADDLE_HEIGHT / 2);
        ballSpeedY = collidePoint * 0.18;
    }

    // Left or right wall (reset)
    if (ballX - BALL_RADIUS < 0 || ballX + BALL_RADIUS > canvas.width) {
        // Reset ball
        ballX = canvas.width / 2;
        ballY = canvas.height / 2;
        ballSpeedX = 5 * (Math.random() > 0.5 ? 1 : -1);
        ballSpeedY = 3 * (Math.random() > 0.5 ? 1 : -1);
    }

    // AI movement
    let aiCenter = aiY + PADDLE_HEIGHT / 2;
    if (aiCenter < ballY - 10) {
        aiY += PADDLE_SPEED * AI_REACTION * Math.abs(ballY - aiCenter) / 10;
    } else if (aiCenter > ballY + 10) {
        aiY -= PADDLE_SPEED * AI_REACTION * Math.abs(ballY - aiCenter) / 10;
    }
    if (aiY < 0) aiY = 0;
    if (aiY > canvas.height - PADDLE_HEIGHT) aiY = canvas.height - PADDLE_HEIGHT;

    // Draw everything
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawNet();
    drawRect(PLAYER_X, playerY, PADDLE_WIDTH, PADDLE_HEIGHT, "#0ff");
    drawRect(AI_X, aiY, PADDLE_WIDTH, PADDLE_HEIGHT, "#f00");
    drawCircle(ballX, ballY, BALL_RADIUS, "#fff");

    requestAnimationFrame(gameLoop);
}

gameLoop();